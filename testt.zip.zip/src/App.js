import './App.css';
import React, { useState, useEffect } from 'react';
import Home from './components/home.jsx'
// import CircleLoader from "react-spinners/CircleLoader";

function App() {
  return (
  <> 
      <main> 
        <Home/> 
      </main>

      <br/>
    
  </>
  );
}
export default App;
