HOW TO BUILD THE APPLICATION
1. Download the files or clone the repository in your local folder. 
2. Open the folder in your source code editor.
3. Install node modules using your Terminal. Enter "npm install".
4. Run the app by entering "npm start".
5. Build the app for production by entering "npm run build".